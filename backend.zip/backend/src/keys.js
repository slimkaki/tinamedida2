module.exports = Object.freeze({
    mailKeys: {
        service: 'gmail',
        auth: {
        user: 'envio@tinamedida.com.br',
        pass: 'cFeDVcMcn@2020'
        }
    },
    atlasKeys: 'senhanamedida'
});

