export const images = [
    "https://pplware.sapo.pt/wp-content/uploads/2019/10/cloud_capa-720x410.jpg",
    "https://specials-images.forbesimg.com/imageserve/1010819940/960x0.jpg?fit=scale",
    "https://i0.wp.com/www.telesintese.com.br/wp-content/uploads/2015/10/polygonal-cloud-computing.jpg?fit=936%2C603",
    "https://pplware.sapo.pt/wp-content/uploads/2019/01/cloud_open.jpg",
];